function m = mymean(X,r)

n = size(X,r); 
m = 1/n*sum(X,r);
