function [MIh,alphah,Kxp,Kyp,p_chosen,lambda_chosen,sigma_chosen_index,Hh,hh]=LSMI(x,y)
%
% Least-Squares Mutual Information (with likelihood cross validation)
%
% Estimating a squared-loss variant of mutual information
%    \frac{1}{2}\int\int (\frac{p_{xy}(x,y)}{p_x(x)p_y(y)}-1)^2 p_x(x)p_y(y) dx dy
% from input-output samples
%    { (x_i,y_i) | x_i\in R^{dx}, y_i\in R^{dy} }_{i=1}^n
% drawn independently from a joint density p_{xy}(x,y).
% p_x(x) and p_y(y) are marginal densities of x and y, respectively.
%
% Usage:
%       [MIh,score_cv]=LSMI(x,y,y_type,sigma_list,lambda_list,b)
%
% Input:
%    x          : dx by n input sample matrix
%    y          : dy by n output sample matrix
%    y_type     : if y_type=1, delta kernel is used for y;
%                 otherwise (or empty) Gaussian kernel is used.
%    sigma_list : (candidates of) Gaussian width
%                 If sigma_list is a vector, one of them is selected by cross validation.
%                 If sigma_list is a scalar, this value is used without cross validation
%                 If sigma_list is empty/undefined, Gaussian width is chosen from
%                 some default canditate list by cross validation
%    lambda_list: (OPTIONAL) regularization parameter
%                 If lambda_list is a vector, one of them is selected by cross validation.
%                 If lambda_list is a scalar, this value is used without cross validation
%                 If lambda_list is empty, Gaussian width is chosen from
%                 some default canditate list by cross validation
%    b          : number of Gaussian centers (if empty, b=200 is used);
%
% Output:
%    MIh        : estimated mutual information between x and y
%    score_cv   : cross validation score
%
% (c) Taiji Suzuki, Department of Mathematical Informatics, The University of Tokyo, Japan.
%     Masashi Sugiyama, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     s-taiji@stat.t.u-tokyo.ac.jp
%     sugi@cs.titech.ac.jp,

% load imgdata_grid;
% x = imgdata;
% y = griddata;

if nargin<3
    compflag = 0;
else
    compflag = 1;
end

n = size(x,2);

sigma1 = compmedDist(x');
sigma2 = compmedDist(y');

%lambda_list = 0.001;
lambda_list= [0.1 0.01 0.001];%logspace(-3,1,9);
%lambda_list= [0.1];
%p_list = 0.1;
p_list = [0.1:0.1:1];
%p_list = [0.2:0.2:2];
%p_list = [0.01 0.1 0.2 0.3:0.3:3];
%p_list = [0.1:0.1:0.5];
%if nargin<10 || isempty(fold)
fold=2;
%end

b=size(x,2);

cv_index = randperm(b);

fold_index=[1:fold];
%cv_index=randperm(n);
cv_split=floor([0:n-1]*fold./n)+1;
scores_cv=zeros(length(p_list),length(lambda_list));

Kx = kernel_Gaussian(x,x,sigma1);
Ky = kernel_Gaussian(y,y,sigma2);

for p_index=1:length(p_list)
    pvalue = p_list(p_index);
    Kxp = Kx.^pvalue;
    Kyp = Ky.^pvalue;

    Phi_p= Kxp.*Kyp;

    for i=fold_index
        cv_index_tmp=cv_index(cv_split==i);
        HH_cv_Phix(:,:,i)=Kxp(:,cv_index_tmp)*Kxp(:,cv_index_tmp)';
        HH_cv_Phiy(:,:,i)=Kyp(:,cv_index_tmp)*Kyp(:,cv_index_tmp)';
        hh_cv(:,:,i)=mean(Phi_p(:,cv_index_tmp),2);
        n_cv(i)=length(cv_index_tmp);
    end

    for i=fold_index
        cv_index_tr=fold_index(fold_index~=i);
        Hh_cv_tr=sum(HH_cv_Phix(:,:,cv_index_tr),3) ...
            .*sum(HH_cv_Phiy(:,:,cv_index_tr),3)/(sum(n_cv(cv_index_tr))^2);
        Hh_cv_te=HH_cv_Phix(:,:,i).*HH_cv_Phiy(:,:,i)/(n_cv(i)^2);
        hh_cv_tr=mean(hh_cv(:,:,cv_index_tr),3);
        hh_cv_te=hh_cv(:,:,i);
        %keyboard
        for lambda_index=1:length(lambda_list)
            lambda=lambda_list(lambda_index);
            alphah_cv=mylinsolve(Hh_cv_tr+lambda*eye(b),hh_cv_tr);
            %keyboard
            %alphah_cv = max(0,alphah_cv);
            wh_cv=alphah_cv'*(Hh_cv_te+lambda*eye(b))*alphah_cv/2-hh_cv_te'*alphah_cv;
            %wh_cv=alphah_cv'*(Hh_cv_te)*alphah_cv/2-hh_cv_te'*alphah_cv;
            %wh_cv= -hh_cv_te'*alphah_cv/2;
            scores_cv(p_index,lambda_index)=scores_cv(p_index,lambda_index)+wh_cv/fold;
        end % fold
    end % lambda
end % sigma
[scores_cv_tmp,lambda_chosen_index]=min(scores_cv,[],2);
[score_cv,sigma_chosen_index]=min(scores_cv_tmp);
%keyboard
lambda_chosen=lambda_list(lambda_chosen_index(sigma_chosen_index));
p_chosen=p_list(sigma_chosen_index);

%keyboard
%%%%%%%%%%%%%%%% Computing the final solution `MIh'

Kxp = Kx.^p_chosen;
Kyp = Ky.^p_chosen;

Phi=Kxp.*Kyp;
Hh=(Kxp*Kxp').*(Kyp*Kyp')/(n^2);
hh=mean(Phi,2);
alphah=mylinsolve(Hh+lambda_chosen*eye(b),hh);
%keyboard
alphah_tmp = alphah;
%alphah_tmp = max(0,alphah);
MIh=hh'*alphah_tmp/2-1/2;


%keyboard