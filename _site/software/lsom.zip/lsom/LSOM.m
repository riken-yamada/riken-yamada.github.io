function [PI_final,MIh_final] = LSOM(X1,X2,n_iter,initp)
%
% Least-Squares Object Matching (LSOM)
%
%
% Usage:
%       [PI_final,MIh,alphah] = LSOM(X1,X2,n_iter,initp)
%
% Input:
%    X1:          d1 by n sample matrix
%    X2:          d2 by n sample matrix
%    n_iter:      (OPTINLAL) positive integer representing the number of iterations (default: 20)
%    initp:       (OPTINLAL) positive value representing the kernel width
%                            in initialization (default: 1)
%
%
% Output:
%    PI_final:    Estimated permutation matrix
%    MIh_final:   Estimated SMI score
%
% (c) Makoto Yamada, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     yamada@sg.cs.titech.ac.jp
 
seed = 1;
rand('state',seed);
randn('state',seed);

%keyboard
if nargin<2
    error('number of input arguments is not enough!!!')
end

[d,   n1]=size(X1);
[d_nu,n2]=size(X2);
if n1~=n2
    error('Number of two samples are diferent!!!')
end

if nargin<3 || isempty(n_iter)
    n_iter = 20;
end

if nargin<4 || isempty(initp)
    initp = 1;
end


current_path = pwd;
addpath([current_path '/hungarian/']);
sigma1 = compmedDist(X1');
sigma2 = compmedDist(X2');

init_type = 'eig';
llambda = 1;
%n_iter = 1;
n_obs = size(X1,2);

%Initializing permutation matrix
Kx = kernel_Gaussian(X1,X1,sigma1);
Kxinitp = Kx.^initp;
Ky = kernel_Gaussian(X2,X2,sigma2);
Kyinitp = Ky.^initp;
[V_1,U_1,G_1] = svds(Kxinitp,1);
[V_2,U_2,G_2] = svds(Kyinitp,1);
[val,i_V1] = sort(-V_1(:,1));
[val,i_V2] = sort(-V_2(:,1));
PI_0 = zeros(n_obs);

u = X1;
v = X2;

for ii = 1:n_obs
    PI_0(i_V2(ii),i_V1(ii)) = 1;
end

PI_final = PI_0;
PI_t = zeros(n_obs);
MIhmax= -100*ones(1,20);
stop_count = 5;
if n_iter > 0
    for ii = 1:n_iter
        
        [val,i_sorting] = max(PI_0);
        [MIh(ii),alphah,Kxp,Kyp,p_chosen,lambda_chosen,pind]=LSMI(X1,X2(:,i_sorting));
        
        alphah = alphah/n_obs;
        

        
        alphah_tmp = max(0,alphah);
        Atp = diag(alphah_tmp);
        
        grad = (Ky.^p_chosen)*PI_0*Atp*Kxp;
        
        cost_matrix = -grad;
        [indexes] = hungarian(cost_matrix);
        %[indexes] = lap(cost_matrix);
        
        PI_t = eye(n_obs);
        PI_t = PI_t(indexes,:);
        
        tmp1 = trace(PI_t'*(Ky.^p_chosen)*PI_t*Atp*Kxp);
        tmp2 = trace(PI_t'*(Ky.^p_chosen)*PI_0*Atp*Kxp);
        
        if MIh(ii) > MIhmax(pind)
            PI_t = eye(n_obs);
            PI_t = PI_t(indexes,:);
            
            PI = (1-llambda)*PI_0 + (llambda)*PI_t;
            
            PI_0 = PI;
            MIhmax(pind) = MIh(ii);
        else
            stop_count = stop_count -1;
        end
        
        if stop_count ==0
            break;
        end
    end
    
    PI_final = PI_t;
else
    [val,i_sorting] = max(PI_0);
    [MIh,alphah,Kxp,Kyp,p_chosen,lambda_chosen,pind]=LSMI(X1,X2(:,i_sorting));
end
MIh_final = MIh(end);