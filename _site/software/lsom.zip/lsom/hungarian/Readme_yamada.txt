hungarian

This hungarian.cpp is originally written by Mr. Harold Cooper (hbc@mit.edu), and I wrote a wrapper for Matlab. 

If you have any problem or question about mex programming part, please contact yamada@sg.cs.titech.ac.jp.

If you have any further question about hungarian algorithm implementation, please contact hbc@mit.edu.
