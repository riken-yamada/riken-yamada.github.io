clear all;
close all;

psize = 40;
iname = 'images/img';

current_path = pwd;
addpath([current_path '/hungarian/']);

load usps_all;
ff = 255 - data(:,:,7);

imgdata = ff;
clear data;
seed = 0;
rand('state',seed);
randn('state',seed);

ino = 16;
jno = 20;
tmp = repmat(1:ino,jno,1);
griddata(1,:) = tmp(:)';
griddata(2,:) = repmat(1:jno,1,ino);

aindex = randperm(size(ff,2));

index = aindex(1:(ino*jno));
imgdata = double(ff(:,index))/255;
for ii = 1:size(imgdata,2);
   for jj = 1:16
       for kk = 1:16
           data(ii).aim(jj,kk) = ff((kk-1)*16 + jj,index(ii));
       end
   end
end

[PI,MIh] = LSOM(imgdata,griddata);


[val,i_sorting] = max(PI');
data_sorted = data(i_sorting);
final_image = zeros(ino*16,jno*16);
irange = (1:16:(16*ino+1));
jrange = (1:16:(16*jno+1));
counter = 1;
for ii = 1:ino
    for jj = 1:jno
        final_image(irange(ii):(irange(ii) + 16 -1),jrange(jj):(jrange(jj) + 16-1)) = data_sorted(counter).aim;
        counter = counter + 1;
    end
end

%save grid_order i_sorting;

figure;
colormap gray;
imagesc(final_image)
axis off;
print('-depsc','usps.eps');
print('-dpng','usps.png');