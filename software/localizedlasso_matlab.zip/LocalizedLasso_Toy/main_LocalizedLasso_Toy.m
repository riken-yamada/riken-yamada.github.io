clear all;
close all;

seed = 1;
rand('state',seed);
randn('state',seed);

d = 10;
n = 30;

%Input 
X = (rand(d,n)-0.5)*2;

%Output
Y1 = X(1,1:10) + X(2,1:10) - X(3,1:10) + randn(1,10)*0.01;
Y2 = X(2,11:20) - X(3,11:20) + X(4,11:20) + randn(1,10)*0.01;
Y3 = X(4,21:end) - X(5,21:end) + randn(1,10)*0.01;

Y = [Y1 Y2 Y3];
Y = Y';

%Graph information
I = zeros(d,n);
I(1,1:10) = 1;
I(2,11:20) = 1;
I(3,21:end) = 1;

E = rand(n);
E = E + E';
E = E > 1;

R = I'*I;
R = R/diag(diag(R));
R = max(0,R - E);
R = R - diag(diag(R));

%Network regularization
lam1 = 5;

%Exclusive regularization (Sample-wise sparsity)

lam2 = 0.01;

%0: no bias, 1: add bias (i.e., y_i = w_i^t x_i + b_i)
%Bias term is regularized only in network regularization
biasflag = 1;

%Training
[W, fval] = LocalizedLasso(X,Y,R,lam1,lam2,biasflag);



%Test
if biasflag == 1
    X = [X; ones(1,size(X,2))];
end

Yest = zeros(n,1);
for ii = 1:n
    wte = weber_LocalizedLasso(W,R(ii,:)');
    
    %Below is only for checking Weber algorithm in training set
    Yest(ii) = wte'*X(:,ii);
    
end
err = sqrt(mean((Yest - Y).^2))
 
figure;
set(gca,'FontSize',24);
imagesc(W);
ylabel('Features');
xlabel('Samples');
colorbar('FontSize',24);

figure;
set(gca,'FontSize',24);
plot(fval,'LineWidth',3);
ylabel('Objective Score');
xlabel('Iteration');
axis([1 20 0 70]);

print('fval.eps','-depsc');

