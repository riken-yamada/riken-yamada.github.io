function [wte,loss_weber] = weber_LocalizedLasso(W,rte)

d = size(W,1);
wte = randn(d,1);

loss_weber = zeros(50,1);
if sum(rte) == 0
    wte = mean(W,2);
else
    for k = 1:50
        %Solve least squares
        dist2 = pdist2(wte',W');
        invdist2 = (rte')./(2*pdist2(wte',W') + 10e-5);
        sum_dist2 = sum(invdist2);
        wte = W*invdist2'/sum_dist2;
        loss_weber(k) = sum((rte').*dist2);
    end
end
