function [alpha] = l_HSICLasso(xin,yin,ylabel,nfeat)

addpath([pwd '/dal/']);

[d,n] = size(xin);

%Normalization
x = xin./(std(xin')'*ones(1,size(xin,2)) + eps);
x = x - mean(x,2)*ones(1,size(x,2));

% Quantization
max_x = 20;
min_x = -20;
qsize = 2048;

step = (max_x - min_x)/qsize;

tmp = (min_x + step):step:max_x;

Kq = kernel_Gaussian(tmp,tmp,1);
kq = Kq(qsize/2,(qsize/2):end);

xind = round(x/step) + qsize/2;


%Transformation of output
%Centering matrix
H = eye(n) - 1/n*ones(n);

%ylabel: 1 regression, 2 classification 
if ylabel == 1
    %medy = compmedDist(y');
    y = yin/(std(yin) + eps);
    L = kernel_Gaussian(y,y,1.0);
else
    y = yin;
    L = DeltaBasis_ycomp(y,y);
end

tmp = H*L*H;
LH = tmp(:);

KHLH = zeros(d,1);
%Transformation of input
MK = zeros(n,d);
%keyboard
for ii = 1:d
    %keyboard
    Kx = Kq(xind(ii,:),xind(ii,:));
    MK(:,ii) = mean(Kx,2) - 0.5*mean(Kx(:));
    tmp = Kx;% - MK(:,1)*ones(1,size(Kx,2)) - ones(size(Kx,1),1)*MK(:,1)';
    
    KHLH(ii) = tmp(:)'*LH;
 end

alpha = KHLH;


