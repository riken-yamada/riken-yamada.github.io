function y = calcAx(xind,Kq,MK,alpha)

[d n] = size(xind);

ind = find(alpha ~= 0);
Y = zeros(n);
for k = 1:length(ind)
    idx = ind(k);
    Y = Y + alpha(idx)*(Kq(xind(idx,:),xind(idx,:))- repmat(MK(:,idx),1,size(xind,2)) - repmat(MK(:,idx)',size(xind,2),1));
end

y = Y(:);
