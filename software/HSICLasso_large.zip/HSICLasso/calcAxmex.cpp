#include <stdio.h>
#include <stdlib.h>
#include "mex.h"
#include "math.h"
#include "omp.h"
#include "eigen/Eigen/Dense"

using namespace Eigen;
using namespace std;

#define MAT(X, row, i, j) ((X)[(i)+(j)*row])
#define MATs(X, shift, i, j) ((X)[(i)+(j << shift)])

void mexFunction( int Nreturned, mxArray *returned[], int Noperand, const mxArray *operand[] ){
	
    int d, n;
    int dq, nq;
    int dm, nm;
    int da, na;
    int ii,jj,ind;
    int *index;
	    
	double *Xin;
    double *kq;
    double *MK;
    double *alpha;
    double *y;
    double *mk;
    
 
	Xin    = mxGetPr(operand[0]);
	d      = mxGetM(operand[0]);
	n      = mxGetN(operand[0]);

    kq     = mxGetPr(operand[1]);
    dq     = mxGetM(operand[1]);
	nq     = mxGetN(operand[1]);
    
    MK     = mxGetPr(operand[2]);
    dm     = mxGetM(operand[2]);
	nm     = mxGetN(operand[2]);
    
    alpha  = mxGetPr(operand[3]);
    da     = mxGetM(operand[3]);
    na     = mxGetN(operand[3]);

    returned[0] = mxCreateDoubleMatrix(n*n,1, mxREAL);
    y = mxGetPr(returned[0]); 
    
    
    index   = (int*)malloc(sizeof(int)*n);
    mk      = (double*)malloc(sizeof(double)*n);
    
    for(int k = 0; k < d; k++){
        //Working memory
        //This is for reducing memory access
        if(alpha[k] != 0){
            for(int i = 0; i < n; i++){
                index[i] = (int)MAT(Xin,d,k,i);
                mk[i] = MAT(MK,dm,i,k);
            }
            
            for(int i = 0; i < n; i++){
                for(int j = 0; j < n; j++){
                    ind = abs(index[i] - index[j]);
                    MAT(y,n,i,j) +=  alpha[k]*(kq[ind] - mk[i] - mk[j]);//*alpha[k];
                }
            }
        }
    }
    free(index);
    free(mk);
}

