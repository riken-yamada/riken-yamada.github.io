function KH = sliceA(xind,Kq,MK,I)

[d,n] = size(xind);
KH = zeros(n^2,length(I));

for k = 1:length(I)
    idx = I(k);
    tmp = Kq(xind(idx,:),xind(idx,:)) - repmat(MK(:,idx),1,size(xind,2)) - repmat(MK(:,idx)',size(xind,2),1);
    KH(:,k) = tmp(:);
end
