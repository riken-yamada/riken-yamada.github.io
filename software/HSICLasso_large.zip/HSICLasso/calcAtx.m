function yt = calcAtx(xind,Kq,MK,alpha)

[d n] = size(xind);
%keyboard
yt = zeros(d,1);
%tic
for k = 1:d
    idx = k;
    tmp = Kq(xind(idx,:),xind(idx,:)) - repmat(MK(:,idx),1,size(xind,2)) - repmat(MK(:,idx)',size(xind,2),1);
    yt(k) = alpha'*tmp(:);

end
%toc
 