#include <stdio.h>
#include <stdlib.h>
#include "mex.h"
#include "math.h"
#include "omp.h"
#include "eigen/Eigen/Dense"

using namespace Eigen;
using namespace std;

#define MAT(X, row, i, j) ((X)[(i)+(j)*row])
#define MATs(X, shift, i, j) ((X)[(i)+(j << shift)])

void mexFunction( int Nreturned, mxArray *returned[], int Noperand, const mxArray *operand[] ){
	
    int d, n;
    int dq, nq;
    int dm, nm;
    int da, na;
    int ii,jj,ind;
	int *index;
    
	double *Xin;
    double *kq;
    double *MK;
    double *alpha;
    double *alphaod;
    double *alphad;
	double *y;
    double tmpod,tmpd;
    double *mk;
    double mk1,mk2;
 
	Xin    = mxGetPr(operand[0]);
	d      = mxGetM(operand[0]);
	n      = mxGetN(operand[0]);

    kq     = mxGetPr(operand[1]);
    dq     = mxGetM(operand[1]);
	nq     = mxGetN(operand[1]);
    
    MK     = mxGetPr(operand[2]);
    dm     = mxGetM(operand[2]);
	nm     = mxGetN(operand[2]);
    
    alpha  = mxGetPr(operand[3]);
    da     = mxGetM(operand[3]);
    na     = mxGetN(operand[3]);

    returned[0] = mxCreateDoubleMatrix(d,1, mxREAL);
    y = mxGetPr(returned[0]); 
    
    //alphaod = (double*)malloc(sizeof(double)*((n*(n+1))/2));
    alphaod = (double*)malloc(sizeof(double)*(n*n)); //I should fix this part
    alphad  = (double*)malloc(sizeof(double)*n); 
    mk      = (double*)malloc(sizeof(double)*n);
    index   = (int*)malloc(sizeof(int)*n);
    //Working memory
    //This is for reducing memory access cost of alpha;
    int countod = 0;
    int countd  = 0;
    for(int i = 0; i < n; i++){
        for(int j = i; j < n; j++){
            if(i == j){
                alphad[countd] = MAT(alpha,n,i,i);
                countd++;
            }else{
                alphaod[countod] = MAT(alpha,n,i,j);
                countod++;
            }
        }
    }
    
  
    //Since kernel matrices are diagonal, we only need to compute n*(n+1)/2
    for(int k = 0; k < d; k++){
        tmpod = 0.0; 
        tmpd = 0.0;
        
        //Working memory
        //This is for reducing memory access
        for(int i = 0; i < n; i++){
            index[i] = (int)MAT(Xin,d,k,i);
            mk[i] = MAT(MK,dm,i,k);
            tmpd += (kq[0] - 2.0*mk[i])*alphad[i]; //Calculate diagonal part
        }
        
        //Calculate off diagonal part
        countod = 0;
        for(int i = 0; i < n; i++){
            #pragma omp parallel for shared(Xin,MK,kq,k,mk1,countod) private(j,jj,ind,mk2) reduction(+: sum)
            for(int j = i+1; j < n; j++){
                ind = abs(index[i] - index[j]);
                
                tmpod += (kq[ind] - mk[i] - mk[j])*alphaod[countod];//MAT(alpha,n,i,j);
                countod++;
            }
        }
        y[k] = 2.0*tmpod + tmpd;
    }
    free(alphaod);
    free(alphad);
    free(mk);
    free(index);
}

