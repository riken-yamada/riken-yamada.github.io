function [alpha] = HSICLasso(xin,yin,ylabel,nfeat)

addpath([pwd '/dal/']);

[d,n] = size(xin);

%Normalization
x = xin./(std(xin')'*ones(1,size(xin,2)) + eps);

%Centering matrix
H = eye(n) - 1/n*ones(n);



%Transformation of output
%ylabel: 1 regression, 2 classification 
if ylabel == 1
    %medy = compmedDist(y');
    y = yin/(std(yin) + eps);
    L = kernel_Gaussian(y,y,1.0);
else
    y = yin;
    L = DeltaBasis_ycomp(y,y);
end

tmp = H*L*H;
LH = tmp(:);

%Transformation of input
KH = zeros(n^2,d);
for ii = 1:d
    %medx = compmedDist(x(ii,:)');
    Kx = kernel_Gaussian(x(ii,:),x(ii,:),1.0);
    
    tmp = H*Kx*H;
    KH(:,ii) = tmp(:);
    
    KHLH(ii) = tmp(:)'*LH;
end



val = sort(-KHLH);
lambda = -val(nfeat+1);

%Solve Lasso problem.
[alpha,status] = dalsql1n(zeros(d,1),KH,LH,lambda);

