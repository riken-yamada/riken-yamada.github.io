//This is just a wrapper of Harold Cooper's
#include <stdio.h>
#include <stdlib.h>
#include "mex.h"
#include "math.h"
#include "omp.h"
#include "../../eigen/Eigen/Dense"

using namespace Eigen;
using namespace std;

#define MAT(X, row, i, j) ((X)[(i)+(j)*row])
#define MATs(X, shift, i, j) ((X)[(i)+(j << shift)])

/*
[d n] = size(xind);
yt = zeros(d,1);
for k = 1:d
    idx = k;
    tmp = Kq(xind(idx,:),xind(idx,:)) - repmat(MK(:,idx),1,size(xind,2)) - repmat(MK(:,idx)',size(xind,2),1);
    yt(k) = alpha'*tmp(:);
end */

void mexFunction( int Nreturned, mxArray *returned[], int Noperand, const mxArray *operand[] ){
	
    int d, n;
    int dq, nq;
    int dm, nm;
    int di, ni;
    int n2;
    int ii,jj,ind;
    int *index;
	    
	double *Xin;
    double *kq;
    double *MK;
    double *I;
    double *y;
    double *mk;
    
 
	Xin    = mxGetPr(operand[0]);
	d      = mxGetM(operand[0]);
	n      = mxGetN(operand[0]);

    kq     = mxGetPr(operand[1]);
    dq     = mxGetM(operand[1]);
	nq     = mxGetN(operand[1]);
    
    MK     = mxGetPr(operand[2]);
    dm     = mxGetM(operand[2]);
	nm     = mxGetN(operand[2]);
    
    I      = mxGetPr(operand[3]);
    di     = mxGetM(operand[3]);
    ni     = mxGetN(operand[3]);

    returned[0] = mxCreateDoubleMatrix(n*n,ni, mxREAL);
    y = mxGetPr(returned[0]); 
    
    
    index   = (int*)malloc(sizeof(int)*n);
    mk      = (double*)malloc(sizeof(double)*n);
    n2 = n*n;
    
    for(int k = 0; k < ni; k++){
        
        for(int i = 0; i < n; i++){
            index[i] = (int)MAT(Xin,d,(int)I[k],i);
            mk[i] = MAT(MK,dm,i,(int)I[k]);
        }
        
        int count = 0;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                ind = abs(index[i] - index[j]);
                MAT(y,n2,count,k) =  kq[ind] - mk[j] - mk[i];//*alpha[k];
                count++;
            }
        }
    }
    free(index);
    free(mk);
}

