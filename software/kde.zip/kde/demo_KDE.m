% demo_KDE.m
%
% (c) Makoto Yamada, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     yamada@sg.cs.titech.ac.jp

clear all

seed = 1;
rand('state',seed);
randn('state',seed);

%%%%%%%%%%%%%%%%%%%%%%%%% Generating data
d=1;
n     =1000;
mu    =1;
sigma =1/4;

x=mu+sigma*randn(d,n);

x_disp=linspace(-0.5,3,100);
p_disp=pdf_Gaussian(x_disp,mu,sigma);

p_kde = KDE(x,x_disp);

figure;
set(gca,'fontsize',24);
plot(x_disp,p_disp,'LineWidth',2);hold on;
plot(x_disp,p_kde,'r','LineWidth',2); hold off;
legend('TRUE','KDE');


