function pte = KDE(X,Xtest)

med = compmedDist(X');
siglist = [0.4 0.6 1.0 1.2 1.4]*med;

[d n_nu] = size(X); 
fold = 5;
cv_indeX=randperm(n_nu);
cv_split_nu=floor([0:n_nu-1]*fold./n_nu)+1;

%Log-Likelihood Cross-Validation
for jj = 1:length(siglist)
    sig = siglist(jj);
    
    s = (2*pi)^(-d/2)/prod(sig)^d;
    K = kernel_Gaussian(X,X,sig);
   
    scoret = zeros(1,fold);
    for k = 1:fold
        ind = cv_indeX(cv_split_nu~=k);
        indte = cv_indeX(cv_split_nu==k);
        p_est = s*mean(K(ind,indte),1);
        scoret(k) = scoret(k) + mean(log(p_est));
    end
    score(jj) = mean(scoret);
end

[val,ind] = max(score);

optsig = siglist(ind);

s = (2*pi)^(-d/2)/prod(optsig)^d;
K = kernel_Gaussian(X,Xtest,optsig);

pte = s*mean(K,1);
