function pte = KDE(X,Xtest)

med = compmedDist(X');
siglist = [0.4 0.6 1.0 1.2 1.4]*med;

%X = ;
[d n_nu] = size(X); 
fold = 5;
cv_indeX=randperm(n_nu);
cv_split_nu=floor([0:n_nu-1]*fold./n_nu)+1;

% tmp=(x-repmat(mu,[1 nx]))./repmat(sigma,[d nx])/sqrt(2);
%  px=(2*pi)^(-d/2)/prod(sigma)^d*exp(-sum(tmp.^2,1));


for jj = 1:length(siglist)
    sig = siglist(jj);
    
    s = (2*pi)^(-d/2)/prod(sig)^d;
    K = kernel_Gaussian(X,X,sig);
   
    scoret = zeros(1,fold);
    for k = 1:fold
        ind = cv_indeX(cv_split_nu~=k);
        indte = cv_indeX(cv_split_nu==k);
        %xce = X(:,ind);
        %xte = X(:,indte);
%         pxnu = pdf_Gaussian(xte,xce(:,1),sig);
%         for ii = 1:length(ind)
%           pxnu = pxnu + pdf_Gaussian(xte,xce(:,ii),sig);
%         end
%         p_est = pxnu/length(indte);
        
        p_est = s*mean(K(ind,indte),1);
        
        %keyboard
        scoret(k) = scoret(k) + mean(log(p_est));
    end
    score(jj) = mean(scoret);
end

[val,ind] = max(score);

optsig = siglist(ind);

s = (2*pi)^(-d/2)/prod(optsig)^d;
K = kernel_Gaussian(X,Xtest,optsig);

pte = s*mean(K,1);

% pxnu = pdf_Gaussian(Xtest,X(:,1),optsig);
% for ii = 1:n_nu
%     pxnu = pxnu + pdf_Gaussian(Xtest,X(:,ii),optsig);
% end
% pte = pxnu/n_nu;

%keyboard