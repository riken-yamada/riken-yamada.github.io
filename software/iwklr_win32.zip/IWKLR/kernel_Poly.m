function X=kernel_Poly(x,c,order)

X= (x'*c + 1).^order;
 