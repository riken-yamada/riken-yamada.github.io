Importance Weighted Kernel Logistic Regression
Author: Makoto Yamada
Web   : http://sugiyama-www.cs.titech.ac.jp/~yamada
e-mail: yamada@sg.cs.titech.ac.jp

(Ver. 0.0.1) Released
(Ver. 0.0.2) Modified Readme.txt

The included pre-compiled mex file is only applicable for Matlab 2006a or later.
If you want to use this function on Version 7.0, please compile klr_train.cpp as

1. Install Visuall C++ Express 2008 or other version of VC++,
2. Run "mex -setup" on Matlab and choose VC++ as the main compiler,
3. Run "mex klr_train.cpp -L./" on Matlab.

main_KLR.m          : KLR demo
main_KLR_3class     : KLR demo for 3 class classification
main_IWKLR.m        : IWKLR demo 
                     (Need KLIEP.m:http://sugiyama-www.cs.titech.ac.jp/~sugi/software/KLIEP/index.html)
kernel_Gaussian.m   : Gaussian kernel computation
kernel_Poly.m       : Polynomial Kernel computation
mlogistic.m         : Logistic transform
kernel_train.mexw32 : Kernel Logistic Regression

If you use this script to write a paper, please refer the following paper.

Yamada, M., Sugiyama, M., & Matsui, T. Semi-supervised speaker identification under covariate shift. Signal Processing, vol.90, no.8, pp.2353-2361, 2010. 

Copyright (c) 2010 Makoto Yamada, All rights reserved.
