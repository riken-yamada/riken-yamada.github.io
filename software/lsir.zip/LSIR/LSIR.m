function [MIh,MIh0,y_est,e_opt,e_ori,u,v,alpha,ite] = LSIR(x,y,b,sigma,delta)

n = size(x,2);

%mx = mean(x);
%x  = x - mx;
my = mean(y);
%�[�����ς��Ȃ��ƁA�ǂ�ǂ�ςȉ��Ɏ���B
y = y - my;

b = min(b,n);

rand_index=randperm(n);
cv_index = randperm(n);
u=x(:,rand_index(1:b));

c=x(:,rand_index(1:b));

%Ktrain = kernel_Gaussian(x,c,sigma);
Phix_tmp=GaussBasis_sub(x,c)';
Ktrain=GaussBasis(Phix_tmp,sigma)';
Kc = Ktrain';
alpha = pinv(Ktrain'*Ktrain+ 1*eye(b))*Ktrain'*y';
%alpha = lsqnonneg(Ktrain,y');
%keyboard

alpha_ori = alpha;
alpha = pinv(Ktrain'*Ktrain+ 1*eye(b))*Ktrain'*y';;
y_est = Ktrain*alpha;

%plot(y,'.'); hold on; plot(y_est,'r'); hold off;
y_est_ori = y_est;
m_yest = mean(y_est);
y_est = y_est - m_yest;
e = y - y_est';
e_ori = e;
e_opt =e;
v= e(:,rand_index(1:b));
[MIh0,alphah,score_cv,sigma_chosen, lambda_chosen]=LSMI(x,e,u,v,cv_index);


%[MIh,alphah,score_cv]=LSMI(x,e,u,v,cv_index);
%Phi_tmp =GaussBasis_sub([x;e],[u;v])';
%Phix_tmp=GaussBasis_sub(x,u)';
%Phiy_tmp=GaussBasis_sub(e,v)';

%alpha = zeros(size(alpha));
%if MIh0 > 0
%eta = 0.2; %NIPS
eta = 0.1;
MIh_old = MIh0;
deccount = 0;
for ite = 1:300
    %Compute gradient
    D2 = ((repmat(e',1,b)-repmat(v,n,1)))';
    
    Phi_tmp =GaussBasis_sub([x;e],[u;v])';
    %Phix_tmp=GaussBasis_sub(x,u)';
    %Phiy_tmp=GaussBasis_sub(e,v)';
    
    Phixy = GaussBasis(Phi_tmp,sigma_chosen);
    %Phix=GaussBasis(Phix_tmp,sigma_chosen);
    %Phiy=GaussBasis(Phiy_tmp,sigma_chosen);
   % 
    %First term
    PhixyD2 = diag(alphah)*Phixy.*D2;
    nabla_MSCh1 = -sum(Kc*PhixyD2',2)/n/sigma_chosen^2;
    
    %Second term
    coeffa = zeros(b,b);
    PhixPhiy   = diag(alphah)*Phixy;
    vecPhixPhiy = sum(PhixPhiy,2);
    PhixPhiyD2 = PhixPhiy.*D2;
    KcPhixPhiyD2 = Kc*PhixPhiyD2';
    for ll1 = 1:length(alpha)
        coeffa = coeffa + KcPhixPhiyD2*vecPhixPhiy(ll1);
    end
    nabla_MSCh2 = -2*sum(coeffa,2)/n^2/sigma_chosen^2;
    
    nabla_MSCh = nabla_MSCh1 - 1/2*nabla_MSCh2;
    
    maxMIh = Inf;
    for ite_in = 1:5
        delta2 = 0.1;
        alpha_tmp = alpha - eta*ite_in*(nabla_MSCh + delta*alpha);
        %alpha_tmp2 = (1 - delta2)*alpha_tmp + delta2*alpha_ori;
        y_est = Ktrain*alpha_tmp;
        %�[�����ς��Ȃ��ƁA�ǂ�ǂ�ςȕ��ɍs���Ă��܂��B
        my_est = mean(y_est);
        y_est = y_est - my_est;
        e = y - y_est';
        
        
        [MIh_in,alphah_tmp,score_cv,sigma_chosen_tmp, lambda_chosen_tmp]=LSMI(x,e,u,v,cv_index);
        %v=e(:,rand_index(1:b));
        if MIh_in < maxMIh
            alpha_opt = alpha_tmp;
            MIh = MIh_in;
            maxMIh = MIh_in;
            sigma_chosen = sigma_chosen_tmp;
            lambda_chosen = lambda_chosen_tmp;
            alphah = alphah_tmp;
            e_opt = e;
            
        else
            deccount = deccount + 1;
        end
    end
    %keyboard
    if MIh > MIh_old & deccount > 20
         
        break;
    end
    MIh_old = MIh;
    
    alpha = alpha_opt;
    
    MIhconv(ite) = MIh;
    %     plot(x,y+my,'.'); hold on; plot(x,y_est+ my_est + my,'r'); plot(x,y_est_ori+my,'k');  hold off;
    %     legend('Data point', 'LSIR', 'KRLS');
    %     drawnow;
end
%MIh = MIh_old;
%end
%plot(MIhconv);
%[MIh,alphah,score_cv,sigma_chosen, lambda_chosen]=LSMI(x,e,u,v,cv_index);
y_est = y - e_opt + my;


 