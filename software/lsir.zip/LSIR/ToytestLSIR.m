%function ToytestLSIR(a)
clear all;

a = 1;
nPerm = 1000;

basis = 200;


ii = 1;
%for ii = 1:100
    seed = 1;
    index = seed;
    rand('state',index);
    randn('state',index);
    
    n=300;
    x=sort(rand(1,n)*2-1);
    lam=1;noise=exprnd(1,n,lam)-1/lam;
    y=f(x)+noise;
    
    x = x - mean(x);
    x = x/std(x);
     
    y = y - mean(y);
    y = y/std(y);
    
    [MIh(ii,1), pval_LSIR(ii,1), y_est,kCVscoreall1, optdelta(ii,1), optsigma(ii,1)] = LSIRTestBoot(x,y,nPerm,basis);
    [MIh(ii,2), pval_LSIR(ii,2), x_est,kCVscoreall2, optdelta(ii,2), optsigma(ii,2)] = LSIRTestBoot(y,x,nPerm,basis);
    pval_LSIR
    %save result_toy pval_LSIR MIh;
    %optsigma 
    %keyboard;
    %median means median in LSIRTestBood
%    sstr = sprintf('result/MLJpval_LSIR_Toy_%d_%d_%d_median', index, basis, nPerm);
    % 
%    save(sstr, 'MIh', 'pval_LSIR', 'optsigma', 'optdelta');
%end    
%exit
