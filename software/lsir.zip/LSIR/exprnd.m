function r = exprnd(m,n,lambda);
%EXPRND	Random matrices from exponential distribution.
%R=EXPRND(M,N,LAMBDA) returns an M by N matrix. 

r=-log(rand(m,n))/lambda;

