function [DmeasuredLSIR,p_LSIR,y_est,kCVscoreall, optdelta, optsigma] = LSIRTestBoot(x,y,nPerm,b,sigma)
% Least-Squares Independence Regression
% 
% Usage:
%       [DmeasuredLSIR,p_LSIR] = LSIRTestBoot(x,y,nPerm,b,sigma)
%
% Input:
%    x          : 1 by n input sample matrix
%    y          : 1 by n output sample matrix
%    nPerm      : Number of iteratio
%    b          : number of Gaussian centers (if empty, b=100 is used)
%    sigma      : Gaussian width for kernel regression
%
% Output:
%    DmeasuredLSIR   : estimated mutual information between x and e = y - f(x)
%    p_LSIR          : estimated p-value using permutation test
%
% (c) Makoto Yamada, Department of Computer Science, Tokyo Institute of Technology, Japan. 
%     Masashi Sugiyama, Department of Compter Science, Tokyo Institute of Technology, Japan.
%     makoto.05@engalumni.colostate.edu
%     sugi@cs.titech.ac.jp
  
if nargin<2
    error('number of input arguments is not enough!!!')
end

Nx =size(x,2);
Ny=size(y,2);

if Nx ~= Ny
    error('x and y must have the same number of samples!!!')
end;

if nargin<3
    nPerm = 100;
end


%Compute the Mutual Information between x and y - f(x)
%DmeasuredLSIR = LSIR(x,y,b,sigma);
%sigma_list=logspace(-2,log10(5),10);
n = length(x);

optdelta = 0.0;
optsigma = compmedDist(x');%median(abs(x));
minCVscore = Inf;

%sigma_list=logspace(log10(0.5*optsigma),log10(optsigma*5),5);
sigma_list = [0.1 1.0]*optsigma;
%sigma_list =[0.75 1.0 1.25 1.5]*optsigma;
%%sigma_list = [0.5 0.75 1.0]*optsigma;
%sigma_list = sigma;
%sigma_list = [0.5 0.75 1.0]*median(abs(x));
%sigma_list = [0.75 1.0 1.25]*median(abs(x));
%lambda_list = [0.1 0.01 0.001 0.0001 0];
%lambda_list = [0.0];
lambda_list = [10^(-5)];

kCVscoreall  = zeros(length(sigma_list),length(lambda_list));

fold=2;
for ll = 1:1
    rand('state',1);
    randn('state',1);
    cv_index = randperm(n);
    cv_split = floor([0:n-1]*fold./n)+1;
    for ii = 1:length(sigma_list)
        for jj = 1:length(lambda_list)
            delta = lambda_list(jj);
            kCVscore = 0.0;
            
            for kk=1:fold
                cv_train_index= cv_index(cv_split~=kk);
                cv_test_index=  cv_index(cv_split==kk);
                
                xtrain = x(cv_train_index);
                ytrain = y(cv_train_index);
                xtest =  x(cv_test_index);
                ytest =  y(cv_test_index);
                
                [MSCh_cv,MSCh0_cv ,y_est,e,e_ori,u,v,alpha] = LSIR(xtrain,ytrain,b,sigma_list(ii),delta);
                
                Phix_test=GaussBasis_sub(xtest,u)';
                Ktest=GaussBasis(Phix_test,sigma_list(ii))';
                
                y_est = Ktest*alpha;
                %b
                m_yest = mean(y_est);
                y_est = y_est - m_yest;
                e = ytest - y_est';
                rand_index = randperm(length(xtest));
                cv_index_lsmi = randperm(length(ytest));
                MIh_cv =LSMI(xtest,e,u,v,cv_index_lsmi);
                kCVscore = kCVscore + MIh_cv/fold;
            end
            
           kCVscoreall(ii,jj) = kCVscoreall(ii,jj) + kCVscore;

        end
    end
end

minCVscore = realmax;
for ii = 1:length(sigma_list)
    for jj = 1:length(lambda_list)
        if kCVscoreall(ii,jj) < minCVscore
            optdelta = lambda_list(jj);
            optsigma = sigma_list(ii);
            minCVscore = kCVscoreall(ii,jj);
        end
    end
end

%keyboard
%optsigma
for ii = 1:5
    %MSCh0_temp(ii) = -1;
    %while MSCh0_temp(ii) < 0
    [MSCh_temp(ii),MSCh0_temp(ii),y_est,e,e_ori,u,v,alpha,ite(ii)] = LSIR(x,y,b,optsigma,optdelta);
    data(ii).u = u;
    data(ii).v = v;
    data(ii).e = e;
    data(ii).y_est = y_est;
    %end
    %      disp(MSCh_temp(ii))
    %      disp(MSCh0_temp(ii))
end
%keyboard
% ind = find(MSCh0_temp < 0);
% if (length(ind) ~= length(MSCh0_temp))
% MSCh_temp(ind) = 100;
% end
 
%[notused,ind] = min(abs(MSCh_temp - median(MSCh_temp)));
[notused,ind] = min(MSCh_temp);
u = data(ind).u;
v = data(ind).v;
e = data(ind).e;
y_est = data(ind).y_est;
DmeasuredLSIR = MSCh_temp(ind);

%Permutation test
DpermLSIR = zeros(nPerm,1);
cv_index = randperm(length(x));
sigmaxy = compmedDist([x' e']);
%sigma_list = [0.5 0.75 1]*sigmaxy;
for r=1:nPerm

    %[tmp,order] = sort(rand(Nx,1));
    order = randperm(Nx);
    orderb = randperm(Nx);
    u = x(:,orderb(1:b));
    v = e(:,orderb(1:b));
    DpermLSIR(r) = LSMI(x,e(order),u,v,cv_index);%,0,sigma_list);
end
% Calculate probability that permuted diff. > measured
p_LSIR = mean( DpermLSIR > DmeasuredLSIR);
%keyboard
