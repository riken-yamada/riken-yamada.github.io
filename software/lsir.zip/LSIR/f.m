function y=f(x)
y=x.^3;
%y=x.^2;
%y=zeros(size(x));
